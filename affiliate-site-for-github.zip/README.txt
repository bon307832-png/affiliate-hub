# Affiliate Site (One-file deploy)
- Mở `index.html` để chạy ngay.
- Đổi `you@example.com` và các link `example.com` sang link affiliate thật (thay YOUR_ID, YOUR_REF, YOUR_TAG).
- Đăng lên nhanh:
  - **Netlify**: drag & drop thư mục này vào app.netlify.com.
  - **Vercel**: tạo project mới, import thư mục này.
  - **GitHub Pages**: repo có `index.html` ở root → Settings → Pages.
