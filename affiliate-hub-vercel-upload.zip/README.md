# Affiliate Hub (Vercel)

Website affiliate tĩnh, triển khai trên Vercel.

## Deploy nhanh
1. Tạo repo GitHub tên `affiliate-hub`.
2. Upload 3 file: `index.html`, `vercel.json`, `README.md`.
3. Vào https://vercel.com → New Project → chọn repo → Deploy.

Sau khi lên, đừng quên thay `affiliateUrl` trong `index.html` bằng link affiliate thật.
